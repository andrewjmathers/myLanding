console.log("hello");
var zoomed = 0;

function pageChangeTest(e){

if($(e.target).hasClass("chosen")){


	return;
	
}





if(e.target.className == "two" ){

$(".chosen").removeClass("chosen");
$(e.target).addClass("chosen");
$("li").css({"color": "white"});
$(".chosen").parent().css({"color": "red"});

function showTheNewOne(){

	$("#mainContent2").css({"grid-area":"secondMenu"});
	$("#Wrapper").css({

	"grid-template-areas": "'header header header header''. siderNav secondMenu . ' '. . . . '"
});

	$("#mainContent2").fadeIn(500);
	$("#mainContent2").fadeIn(0).animate({"opacity":1}).css({"margin-top":"0", "margin-bottom":"0"});


}

	$("#mainContent1").css({"overflow":"hidden"}).animate({"margin-bottom": "15%", "opacity":0},300, showTheNewOne).fadeOut(0);

}	else if(e.target.className == "one"){

	$(".chosen").removeClass("chosen");
	$(e.target).addClass("chosen");
	$("li").css({"color": "white"});
	$(".chosen").parent().css({"color": "red"});

	$("#mainContent1").fadeIn(0).removeAttr("style").animate({"opacity":1});
	$("#mainContent2").css({"overflow":"hidden"}).animate({"margin-top": "15%", "opacity":0},300).fadeOut(0).removeAttr("style");
	$("#mainContent2").css({"grid-area":"secondMenu"});
	$("#Wrapper").removeAttr("style");
	



}

	
}

function redLi(e){

if(e.type == "mouseover"){
	
	if(e.target.parentNode.tagName == "LI"){

		$(e.target.parentNode).css({color: "red"});
	}

}else if(e.type == "mouseleave"){

	console.log("works");
	
	$("li").css({"color": "white"});
	$(".chosen").parent().css({"color": "red"});
}


}

function demensionView(e){

	if(zoomed == 0 && (e.target.id == "cornerNav" || e.target.parentNode.id ==  "cornerNav")){

	$(document.body).css({

		"-webkit-perspective": "1500px", 
		



});
	$("#Wrapper").addClass("wrapperFarView");

	$("#hiddenMenu").css({
		"display":"block",
		"position":"absolute",
		"line-height":"6em",
		"top":"25%",
		"right":"20%",
		"list-style":"none",
	});

	$("#hiddenMenu ul li").css({
		
		"list-style":"none",
		
	});



	zoomed = 1;

}else if(zoomed == 1 && (e.target.id != "cornerNav")){

	$(document.body).removeAttr("style");
	$("#Wrapper").removeClass("wrapperFarView");
	$("#hiddenMenu").removeAttr("style");
	zoomed = 0;
}
}

function animateMargin(event){

if(event.type == "mouseover" || event.type == "mouseenter"){
	
	$("#cornerNav > span").animate({margin:"7px 0" }, 100);
}else{

	$("#cornerNav > span").animate({margin:"3px 0" }, 100);

}
}

function updateRedDot(){

	$(".chosen").parent().css({"color": "red"});
}

updateRedDot();
$("#siderNavMenu").on("mouseover", redLi).on("mouseleave", redLi).on("click", pageChangeTest);
$("span").on("mouseleave", redLi);
$("#cornerNav").on("mouseenter", animateMargin).on("mouseleave", animateMargin).on("click", demensionView);
$("#cornerNav > span").on("click", demensionView);
$("#Wrapper").on("click", demensionView);
